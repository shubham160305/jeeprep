import { config } from 'dotenv';
config();

import '@/ai/flows/hint-system.ts';
import '@/ai/flows/doubt-solving-bot.ts';