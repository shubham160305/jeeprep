<iframe
  src="https://www.youtube.com/embed/live_stream?channel=CHANNEL_ID"
  className="w-full aspect-video"
/>
