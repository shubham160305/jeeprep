'use client';

import AppShell from '@/components/layout/AppShell';
import Header from '@/components/layout/header';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { tutorials } from '@/lib/data';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Clock } from 'lucide-react';
import { useSession } from 'next-auth/react';
import Image from 'next/image';
import Link from 'next/link';
import { redirect } from 'next/navigation';

export default function TutorialsPage() {
  const { data: session, status } = useSession();

  if (status === 'loading') return null;
  if (!session) redirect('/login');

  const imageMap = new Map(PlaceHolderImages.map(img => [img.id, img]));

  return (
    <AppShell>
      <div className="flex min-h-screen w-full flex-col">
        <Header
          title="JEE Video Lectures"
          description="Expand your knowledge with our expert-led courses."
        />

        <main className="flex-1 p-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
            {tutorials.map((tutorial) => {
              const placeholder = imageMap.get(tutorial.imageId);

              return (
                <Link
                  href={`/tutorials/${tutorial.id}`}
                  key={tutorial.id}
                  className="group"
                >
                  <Card className="flex h-full flex-col overflow-hidden transition-all group-hover:shadow-lg group-hover:-translate-y-1">
                    <CardHeader className="p-0">
                      <div className="relative aspect-video w-full">
                        {placeholder && (
                          <Image
                            src={placeholder.imageUrl}
                            alt={tutorial.title}
                            fill
                            sizes="(max-width: 640px) 100vw, (max-width: 1280px) 50vw, 33vw"
                            className="object-cover"
                            data-ai-hint={placeholder.imageHint}
                          />
                        )}
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1 p-4">
                      <CardTitle className="mb-2 font-headline text-lg">
                        {tutorial.title}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {tutorial.description}
                      </p>
                    </CardContent>

                    <CardFooter className="p-4 pt-0">
                      <Badge variant="secondary" className="flex items-center gap-1.5">
                        <Clock className="h-3 w-3" />
                        {tutorial.duration}
                      </Badge>
                    </CardFooter>
                  </Card>
                </Link>
              );
            })}
          </div>
        </main>
      </div>
    </AppShell>
  );
}
