'use client';

import { useSession } from 'next-auth/react';
import { redirect } from 'next/navigation';

export default function CoursePlayer() {
  const { data: session, status } = useSession();

  if (status === 'loading') return null;
  if (!session) redirect('/login');

  return (
    <div className="p-6 space-y-4">
      <iframe
        className="w-full aspect-video rounded"
        src="https://www.youtube.com/embed/VIDEO_ID"
        allowFullScreen
      />

      <button className="rounded bg-green-600 px-4 py-2 text-white">
        Mark as Completed
      </button>
    </div>
  );
}
