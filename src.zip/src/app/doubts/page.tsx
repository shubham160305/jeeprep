'use client';

import ChatInterface from '@/components/doubts/chat-interface';
import AppShell from '@/components/layout/AppShell';
import Header from '@/components/layout/header';
import { useSession } from 'next-auth/react';
import { redirect } from 'next/navigation';

export default function DoubtsPage() {
  const { data: session, status } = useSession();

  if (status === 'loading') return null;
  if (!session) redirect('/login');

  return (
    <AppShell>
      <div className="flex h-screen flex-col">
        <Header
          title="Doubt Solver"
          description="Ask our AI tutor anything about Physics, Chemistry, or Math."
        />

        <main className="flex flex-1 items-center justify-center p-4">
          <div className="h-full w-full">
            <ChatInterface />
          </div>
        </main>
      </div>
    </AppShell>
  );
}
