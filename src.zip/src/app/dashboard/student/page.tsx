'use client';

import ProgressChart from '@/components/dashboard/progress-chart';
import StatsCards from '@/components/dashboard/stats-cards';
import Header from '@/components/layout/header';

export default function StudentDashboard() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header
        title="Student Dashboard"
        description="Your learning progress"
      />

      <main className="flex-1 p-6 space-y-6">
        <StatsCards />
        <ProgressChart />
      </main>
    </div>
  );
}
