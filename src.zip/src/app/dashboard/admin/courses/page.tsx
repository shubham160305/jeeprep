'use client';

import { useSession } from 'next-auth/react';
import { redirect } from 'next/navigation';

export default function AdminCoursesPage() {
  const { data: session, status } = useSession();

  if (status === 'loading') return null;
  if (!session || session.user.role !== 'admin') redirect('/dashboard/student');

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Manage Courses</h1>

      <button className="mt-4 rounded bg-primary px-4 py-2 text-white">
        + Add Course
      </button>
    </div>
  );
}
